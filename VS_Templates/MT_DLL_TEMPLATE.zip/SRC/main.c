#include <WinCLib_PreLoad.h>

/*
* TODO: Safely include all HM FK04 TI3 includes here
*/

int main(int argc, char* argv[]) {
	
	/*
	* TODO: Implement application behaviour
	*/

	return 0;
}
